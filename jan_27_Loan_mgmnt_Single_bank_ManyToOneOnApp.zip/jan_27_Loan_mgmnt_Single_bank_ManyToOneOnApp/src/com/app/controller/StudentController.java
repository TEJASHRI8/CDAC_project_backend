package com.app.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IStudentDao;
import com.app.pojos.Address;
import com.app.pojos.AdmittedCourse;
import com.app.pojos.EntireForm;
import com.app.pojos.Gender;
import com.app.pojos.LoanApplicationForm;
import com.app.pojos.Qualification;
import com.app.pojos.Student;

@RestController
@CrossOrigin
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private IStudentDao dao;

	@PostConstruct
	public void init() {
		System.out.println("in init " + dao);
	}
	
	//////////////Method for getting students details
	@GetMapping
	public ResponseEntity<?> getAllStudents()
	{
		System.out.println("in controller getAllStudents");
		List<Student> allStudents=dao.getAllStudents();
		if(allStudents.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Student>>(allStudents,HttpStatus.OK);
	}
	///////////////////Method for getting student by ID
	
//	@GetMapping("/{s_id}")
//	public ResponseEntity<?> getStudentById(@PathVariable Integer s_id)
//	{
//		System.out.println("get stud details by Id"+s_id);
//		Student s=dao.getStudentById(s_id);
//		if(s == null)
//			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
//		return new ResponseEntity<Student>(s,HttpStatus.OK);
//		
//	}
	///////////getting studnet details by emailid for updating form details
	@GetMapping("/{email}")
	public ResponseEntity<?> getStudentById(@PathVariable String email)
	{
		System.out.println("get stud details by email : "+email);
		Student s=dao.getStudentByEmail(email);
		if(s == null)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Student>(s,HttpStatus.OK);
		
	}
	
	
	//////////////////////////method for getting student by email
	
	@PostMapping("/email")
	public ResponseEntity<?> getStudentByEmail(@RequestBody String email)
	{
		System.out.println("get stud details by email: "+email);
		Student s1=dao.getStudentByEmail(email);
		if(s1 == null)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Student>(s1,HttpStatus.OK);
		
	}
	
	@PostMapping
	public ResponseEntity<?> Login(@RequestBody Student s)
	{
		System.out.println("get stud details by email"+s.getEmail()+s.getPassword());
		Student s1 = dao.login(s);
		if(s1 == null)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Student>(s1,HttpStatus.OK);
		
	}
	
	
	
	
	/////////////method for adding or registering  new student
	
	
	@PostMapping("/{register}")
	public ResponseEntity<?> registerNewStudent(@RequestBody Student s)
	{
		System.out.println("in reg student details"+s);
		try
		{
			return new ResponseEntity<Student>(dao.registerNewStudent(s), HttpStatus.CREATED);
			
		}catch(RuntimeException ex)
		{
			ex.printStackTrace();
			return new ResponseEntity<Student>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	////////////////////////////method for deleting student details
	
	@DeleteMapping("/{s_id}")
	public void deleteStudentDetails(@PathVariable int s_id)
	{	
		System.out.println("in delete student details"+s_id);
		dao.deleteStudentDetails(s_id);
	}
	
	///////////////////////////////////////////Change password of student account
	@PutMapping("/{email}")
	public ResponseEntity<?> updateStudentPassword(@RequestBody String password, @PathVariable String email) {
		System.out.println("in update student " + email + " " + password );

		Student sDetails=dao.getStudentByEmail(email);
			if (sDetails == null)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND); 
			sDetails.setPassword(password);
		
			return new ResponseEntity<Student>(dao.updateStudentDetails(sDetails), HttpStatus.OK);
		

	}
	
	
	
	
	
	/////////////////////////method for applying loan Application
	@PostMapping("/form")
	public ResponseEntity<?> applyForLoan(@RequestBody EntireForm s)
	{
	System.out.println(s);
		Student st=dao.getStudentByEmail(s.getEmail());
		System.out.println(st.toString());
		Qualification q = new Qualification(s.getDegreeName(), 
				s.getYearOfPassing(), 
				s.getObtainedMarks(), 
				s.getTotalMarks());
		Address adr = new Address(s.getAddressLine(), 
				s.getCity(), 
				s.getDistrict(),
				s.getPinCode());
		AdmittedCourse ac = new AdmittedCourse(s.getInstituteName(), 
				s.getCourseName(), s.getStartDate(), 
				s.getEndDate(), s.getCity(), 
				s.getCountry(), s.getCourseFees(), 
				s.getTotalExpenses(),s.getLoanRequired());
		LoanApplicationForm form = new LoanApplicationForm(s.getBirthdate(), s.getFatherName(), 
				s.getOccupation(), s.getIncome(),Gender.MALE, s.getMaritalStatus(), s.getAdharCard());
		dao.addForm(form,st,adr,ac,q);
		System.out.println("in reg student details"+s);
		try
		{
			return new ResponseEntity<>(HttpStatus.OK);
			
		}catch(RuntimeException ex)
		{
			ex.printStackTrace();
			return new ResponseEntity<Student>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
}
