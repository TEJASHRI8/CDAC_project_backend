package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ILoanStatusDao;
import com.app.pojos.LoanStatus;
@RestController
@CrossOrigin
@RequestMapping("/loanStatusctrller")
public class LoanStatusController 
{	@Autowired
	ILoanStatusDao dao;

	@GetMapping("/{applId}")
	public ResponseEntity<?> getloanStatus(@PathVariable int applId )
	{

		System.out.println("VgetloanStatus id="+applId);
		LoanStatus loanStatus= dao.getloanFormStatus(applId);
		if(loanStatus==null)
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	return new ResponseEntity<LoanStatus>(loanStatus,HttpStatus.OK);
		
	}

}
