package com.app.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IBankDao;
import com.app.pojos.Bank;
import com.app.pojos.Student;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/bank")
public class BankController {
	@Autowired
	IBankDao dao;
	
	@PostConstruct
	public void init() {
		System.out.println("in init " + dao);
	}
	
	@PostMapping
	ResponseEntity<?> loginBank(@RequestBody Bank bk)
	{
		System.out.println(bk);
		Bank bk1=dao.loginBank(bk);
		if(bk1==null)
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	return new ResponseEntity<Bank>(bk1,HttpStatus.OK);
			
	}
	
	@GetMapping("/banklist")
	public ResponseEntity<?> getListOfBanks()
	{
		List<Bank> bk=dao.getListOfBanks();
		if(bk==null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Bank>> (bk,HttpStatus.OK);
	}
	
	@PostMapping("/addbank")
	public ResponseEntity<?> addBankDetails(@RequestBody Bank bk)
	{
		System.out.println("in adding bank in admin");
		
		try
		{
			return new ResponseEntity<Bank>(dao.addBankDetails(bk), HttpStatus.CREATED);
			
		}catch(RuntimeException ex)
		{
			ex.printStackTrace();
			return new ResponseEntity<Bank>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/{bankId}")
	public void deleteBDetails(@PathVariable int bankId)
	{
		System.out.println("in delete emp "+bankId);
		Bank bk=dao.getBankById(bankId);
		dao.deleteBank(bk);
	}
	@GetMapping("/{email}")
	public ResponseEntity<?> getBankByEmail(@PathVariable String email)
	{
		Bank bk=dao.getBankByEmail(email);
		if(bk==null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<Bank>(bk,HttpStatus.OK);
	}
	
	
	
}
