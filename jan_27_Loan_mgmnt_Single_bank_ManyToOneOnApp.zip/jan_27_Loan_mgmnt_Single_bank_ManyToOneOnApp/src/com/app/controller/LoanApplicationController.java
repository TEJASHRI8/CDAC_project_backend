package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IBankDao;
import com.app.dao.ILoanApplicationDao;
import com.app.dao.IStudentDao;
import com.app.pojos.Bank;
import com.app.pojos.EntireForm;
import com.app.pojos.LoanApplicationForm;
import com.app.pojos.LoanStatus;
import com.app.pojos.Student;

@RestController
@CrossOrigin
@RequestMapping("/loanApplication")
public class LoanApplicationController {
	
	@Autowired
	ILoanApplicationDao dao;
	@Autowired
	IStudentDao sdao;
	
	@Autowired
	IBankDao bankDao;
	@GetMapping
	public ResponseEntity<?> getListOfLoanApplications()
	{
		List<LoanApplicationForm> forms=dao.getListOfApplications();
		for (LoanApplicationForm loanApplicationForm : forms) {
			System.out.println(loanApplicationForm.toString());
		}
		if(forms == null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<LoanApplicationForm>>(forms,HttpStatus.OK);
	}
	
	@GetMapping("/list")
	public ResponseEntity<?> getListOfStudAppl()
	{
	List<Student> forms=dao.getListOfStudentAppl();
		for (Student studForm : forms) {
			System.out.println(studForm.toString());
		}
		if(forms == null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Student>>(forms,HttpStatus.OK);
	}
	@PostMapping("/listofRespectiveBank")
	public ResponseEntity<?> getListOfApplicationForEachBank(@RequestParam int bank_id)
	{
		List<Student> list=dao.getListOfStudentApplWithBank(bank_id);
		if(list == null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Student>>(list,HttpStatus.OK);
		
	}
	
	
	
	@PostMapping("/approve")
	public ResponseEntity<?> approve(@RequestBody int id)
	{
		System.out.println(id);
		 dao.approve(id);
		 return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@PostMapping("/reject")
	public ResponseEntity<?> reject(@RequestBody int id)
	{
		System.out.println(id);
		 dao.reject(id);
		 return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	
	@PostMapping("/bankId")
	public ResponseEntity<?> getSingleLoanApplication(@RequestParam int bankId)
	{
		System.out.println(bankId);
		List<LoanApplicationForm> loanForm= dao.getSingleLoanApplication(bankId);
		if(loanForm==null)
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	return new ResponseEntity<List<LoanApplicationForm>>(loanForm,HttpStatus.OK);
		
	}
	@PostMapping("/email")
	public ResponseEntity<?> getLoanAppFormByEmailOfStudent(@RequestBody String email)
	{
		System.out.println(email);
		
		Student s=sdao.getStudentByEmail(email);
		System.out.println("Student Details="+s.getFname());
		
		System.out.println("Student Details="+s.getLname());
		LoanApplicationForm loanForm= dao.getLoanAppFormById(s.getSid());
		System.out.println("Loan Form adhar card="+loanForm.getAdharCard());
		if(loanForm==null)
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	return new ResponseEntity<LoanApplicationForm>(loanForm,HttpStatus.OK);
	}
	
	
	@PutMapping("/{bank_id}")
	public ResponseEntity<?> updateLoanApplBankIdDtls(@RequestBody int applId, @PathVariable int bank_id) {
		System.out.println("in update Bank id into loanapplicationform " + bank_id) ;
		System.out.println("formId is"+applId);
		dao.addFormTOBank(applId,bank_id);
		return new ResponseEntity<Void>(HttpStatus.OK); 

	}

	

}
