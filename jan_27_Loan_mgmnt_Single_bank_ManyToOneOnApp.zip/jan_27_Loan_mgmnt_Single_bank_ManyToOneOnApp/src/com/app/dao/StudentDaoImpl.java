package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Address;
import com.app.pojos.AdmittedCourse;
import com.app.pojos.EntireForm;
import com.app.pojos.LoanApplicationForm;
import com.app.pojos.Qualification;
import com.app.pojos.Student;

@Repository
@Transactional
public class StudentDaoImpl implements IStudentDao
{	@Autowired
	private SessionFactory sf;
	
	@Override
	public Student registerNewStudent(Student s)
	{
		sf.getCurrentSession().persist(s);
		return s;
	}

	@Override
	public List<Student> getAllStudents() {
		String jpql="select s from Student s";
		return sf.getCurrentSession().createQuery(jpql, Student.class).getResultList();
	}

	@Override
	public Student getStudentById(int sid) {
		return sf.getCurrentSession().get(Student.class, sid);
	}

	@Override
	public void deleteStudentDetails(int s_id) {
		
		Student s= getStudentById(s_id);
		if(s!=null)
			sf.getCurrentSession().delete(s);
	}

	@Override
	public String applyForLoan(EntireForm s) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudentByEmail(String email) {
		Student s1=new Student();
		s1.setEmail(email);
		System.out.println(email);
		String jpql = "select s from Student s where s.email=:em";
		Student s=sf.getCurrentSession().createQuery(jpql,Student.class).setParameter("em",email).getSingleResult();
		System.out.println(s);
		return s;
	}
	
	@Override
	public Student login(Student s) {
		System.out.println(s.toString());
		String jpql = "select s from Student s where s.email=:em and s.password=:pass";
		return sf.getCurrentSession().createQuery(jpql,Student.class).setParameter("em",s.getEmail()).
				setParameter("pass", s.getPassword()).getSingleResult();
		
	}
	@Override
	public Student updateStudentDetails(Student s) {
		sf.getCurrentSession().update(s);
		return s;
	}
	

	@Override
	public void addForm(LoanApplicationForm form, 
			Student st, 
			Address adr, 
			AdmittedCourse ac, 
			Qualification q) 
	{
		form.setStudent(st);
		ac.setStudentCourse(st);
		adr.setStudentAddr(st);
		sf.getCurrentSession().persist(adr);
		sf.getCurrentSession().persist(ac);
		q.setStudentQuali(st);
		sf.getCurrentSession().persist(q);
		sf.getCurrentSession().persist(form);
	}

}
