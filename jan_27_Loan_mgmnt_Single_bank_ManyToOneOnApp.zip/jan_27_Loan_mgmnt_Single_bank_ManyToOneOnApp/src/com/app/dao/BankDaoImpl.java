package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Bank;
@Repository
@Transactional
public class BankDaoImpl implements IBankDao {
	@Autowired
	SessionFactory sf;
	
	public BankDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Bank loginBank(Bank bk) {
		System.out.println(bk);
		String jpql="select bk from Bank bk where bk.email=:em and bk.password=:pass and bk.role=:role";
		 return sf.getCurrentSession().createQuery(jpql,Bank.class).
				 setParameter("em", bk.getEmail()).
				 setParameter("pass", bk.getPassword())
				 .setParameter("role",bk.getRole()).getSingleResult();			
	}
	
	

	public List<Bank> getListOfBanks()
	{
		String jpql="select b from Bank b";
		return sf.getCurrentSession().createQuery(jpql,Bank.class).getResultList();
		
	}

	@Override
	public Bank addBankDetails(Bank bk)
	{
		sf.getCurrentSession().persist(bk);
		return bk;
	}
	
	
	
	
	@Override
	public Bank deleteBank(Bank bk) {
		sf.getCurrentSession().remove(bk);
		return bk;
	}

	@Override
	public Bank getBankById(int bankId) {
		
		return sf.getCurrentSession().get(Bank.class, bankId);
	}

	@Override
	public Bank getBankByEmail(String email) {
		
		String jpql="select b from Bank b where b.email=:email";
		
		return sf.getCurrentSession().createQuery(jpql,Bank.class).setParameter("email", email).getSingleResult();
	}

}
