package com.app.dao;

import java.util.List;

import com.app.pojos.Address;
import com.app.pojos.AdmittedCourse;
import com.app.pojos.EntireForm;
import com.app.pojos.LoanApplicationForm;
import com.app.pojos.Qualification;
import com.app.pojos.Student;

public interface IStudentDao {
	Student registerNewStudent(Student s);
	List<Student> getAllStudents();
	Student getStudentById(int sid);
	void deleteStudentDetails(int s_id);
	String applyForLoan(EntireForm s);
	Student getStudentByEmail(String email);
	Student login(Student s);
	Student updateStudentDetails(Student s);
	void addForm(LoanApplicationForm form, Student st, Address adr, AdmittedCourse ac, Qualification q);
	
}
