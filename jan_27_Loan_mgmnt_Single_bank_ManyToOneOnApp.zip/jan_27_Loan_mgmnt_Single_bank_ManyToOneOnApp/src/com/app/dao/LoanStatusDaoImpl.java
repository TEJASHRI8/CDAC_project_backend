package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.LoanStatus;
@Repository
@Transactional
public class LoanStatusDaoImpl implements ILoanStatusDao {
@Autowired
SessionFactory sf;

public LoanStatusDaoImpl() {
	System.out.println("inside loanStatusDao implementation");
}
	@Override
	public LoanStatus getloanFormStatus(int applId) {
		String jpql="select l from LoanStatus l left outer join fetch l.loanForm where  l.loanForm.applId=:applId";
		
		System.out.println("in Side getloanFormStatus");
		LoanStatus status= sf.getCurrentSession().createQuery(jpql, LoanStatus.class).setParameter("applId", applId).getSingleResult();
		System.out.println("Status cread="+status.getMessage()+" and status"+status.getStatus());
		return status;
	
		}
	
}
