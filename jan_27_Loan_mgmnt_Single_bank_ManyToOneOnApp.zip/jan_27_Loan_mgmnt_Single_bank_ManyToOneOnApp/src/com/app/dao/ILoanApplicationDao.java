package com.app.dao;

import java.util.List;

import com.app.pojos.Bank;
import com.app.pojos.LoanApplicationForm;
import com.app.pojos.LoanStatus;
import com.app.pojos.Student;

public interface ILoanApplicationDao {

	List<LoanApplicationForm>  getListOfApplications();
	List<Student>  getListOfStudentAppl();
//	LoanApplicationForm addBank(LoanApplicationForm lf,Bank bk);
	void approve(int id);
	void reject(int id);
	
	List<LoanApplicationForm> getSingleLoanApplication(int bankId) ;
	LoanApplicationForm getLoanAppFormById(int app_id);
	List<Student> getListOfStudentApplWithBank(int bank_id);
	void addFormTOBank(int applId, int bank_id);
	LoanApplicationForm getLoanAppFormByStudentId(int sid);

}
