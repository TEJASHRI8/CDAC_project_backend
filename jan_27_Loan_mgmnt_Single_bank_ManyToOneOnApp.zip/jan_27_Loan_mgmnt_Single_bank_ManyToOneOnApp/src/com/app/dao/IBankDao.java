package com.app.dao;

import java.util.List;

import com.app.pojos.Bank;

public interface IBankDao {
	
	Bank loginBank(Bank bk);

	 List<Bank> getListOfBanks();
	 
	 Bank addBankDetails(Bank bk);
	
	 Bank getBankById(int bankId);
	 Bank deleteBank(Bank bk);
	 Bank getBankByEmail(String email);

}
