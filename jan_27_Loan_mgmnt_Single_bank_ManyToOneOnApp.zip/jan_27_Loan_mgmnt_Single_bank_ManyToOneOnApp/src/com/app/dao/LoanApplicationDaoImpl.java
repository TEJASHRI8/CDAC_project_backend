package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Bank;
import com.app.pojos.LoanApplicationForm;
import com.app.pojos.LoanStatus;
import com.app.pojos.Status;
import com.app.pojos.Student;

@Repository
@Transactional
public class LoanApplicationDaoImpl  implements ILoanApplicationDao{
	@Autowired
	SessionFactory sf;

	@Override
	public List<LoanApplicationForm> getListOfApplications() {
		
		String jpql="select l from LoanApplicationForm l left outer join l.student";
		return sf.getCurrentSession().createQuery(jpql,LoanApplicationForm.class).getResultList();
	}
	
	public List<Student> getListOfStudentAppl() {
		
		String jpql="select s from Student s";
		return sf.getCurrentSession().createQuery(jpql,Student.class).getResultList();
	}
	
	public List<Student> getListOfStudentApplWithBank(int bank_id) {
			String jpql="select s from student s inner join fetch s.student inner join fetch s.student.bank where s.student.bank.bankId=:bank_id";		
		return sf.getCurrentSession().createQuery(jpql,Student.class).getResultList();
	}

	
	
	@Override
	public void approve(int id) {
		LoanApplicationForm l = sf.getCurrentSession().get(LoanApplicationForm.class, id);
		Bank b = sf.getCurrentSession().get(Bank.class, 1);
		LoanStatus ls = new LoanStatus();
		ls.setMessage("Loan Sanctioned..! Please submit documents.");
		ls.setBanks(b);
		b.setStatus(ls);
		ls.setLoanForm(l);
		ls.setStatus(Status.APPROVED);
		l.setLoanStatus(ls);
		sf.getCurrentSession().persist(ls);
	}
	
	
	public void reject(int id) {
		LoanApplicationForm l = sf.getCurrentSession().get(LoanApplicationForm.class, id);
		Bank b = sf.getCurrentSession().get(Bank.class, 1);
		LoanStatus ls = new LoanStatus();
		ls.setMessage("Loan rejected..! Sorry.... your application doesn't satisty eligiblity criteria...");
		ls.setBanks(b);
		b.setStatus(ls);
		ls.setLoanForm(l);
		ls.setStatus(Status.REJECTED);
		l.setLoanStatus(ls);
		sf.getCurrentSession().persist(ls);
	}

	
	@Override
	public List<LoanApplicationForm> getSingleLoanApplication(int bankId) {
		
		String jpql="select l from  LoanApplicationForm l inner join fetch l.bank where l.bank.bankId =:bankId";
		return sf.getCurrentSession().createQuery(jpql, LoanApplicationForm.class).
				setParameter("bankId", bankId).getResultList();
	}

	@Override
	public LoanApplicationForm getLoanAppFormById(int app_id)
	{
		return sf.getCurrentSession().get(LoanApplicationForm.class,app_id);	
	}

	

	@Override
	public void addFormTOBank(int applId, int bank_id) {
		System.out.println("1111111111111");
		LoanApplicationForm l =  sf.getCurrentSession().get(LoanApplicationForm.class, applId);
		System.out.println("2222222222222222222222");

		
		Bank b = sf.getCurrentSession().get(Bank.class, bank_id);
		System.out.println("3333333333333");

		//l.addBank(b);
		//b.setLoanAppForm(l);
		b.addLoanApplicationForm(l);
	}

	@Override
	public LoanApplicationForm getLoanAppFormByStudentId(int sid) {
		String jpql="select l from LoanApplicationForm l left outer join fetch l.student where l.student.sid=:sid";
		return sf.getCurrentSession().createQuery(jpql,LoanApplicationForm.class).setParameter("sid", sid).getSingleResult();
	}
	
	

}
