package com.app.dao;

import com.app.pojos.LoanStatus;

public interface ILoanStatusDao {
	LoanStatus getloanFormStatus(int applId);

}
