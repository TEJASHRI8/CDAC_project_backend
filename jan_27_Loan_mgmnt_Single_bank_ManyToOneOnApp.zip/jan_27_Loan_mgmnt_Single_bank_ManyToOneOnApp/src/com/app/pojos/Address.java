package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="address")
public class Address {
	private Integer addressId;
	private String addressLine;
	private String city;
	private String district;
	private String pinCode;
	private Student studentAddr;
			
	public Address() {
		// TODO Auto-generated constructor stub
	}
	
	public Address(String addressLine, String city, String district, String pinCode) {
		super();
		this.addressLine = addressLine;
		this.city = city;
		this.district = district;
		this.pinCode = pinCode;
	}
	
	//////////////////////one to one mapping between Student and Address
	@OneToOne
	@JoinColumn(name="stud_id")
	@JsonIgnore
	public Student getStudentAddr() {
		return studentAddr;
	}

	public void setStudentAddr(Student studentAddr) {
		this.studentAddr = studentAddr;
	}
	
	
	
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	@Column(length=20)
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	@Column(length=20)
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Column(length=20)
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	@Column(length=20)
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "Address [addressLine=" + addressLine + ", city=" + city + ", district=" + district + ", pinCode="
				+ pinCode + "]";
	}
	

}
