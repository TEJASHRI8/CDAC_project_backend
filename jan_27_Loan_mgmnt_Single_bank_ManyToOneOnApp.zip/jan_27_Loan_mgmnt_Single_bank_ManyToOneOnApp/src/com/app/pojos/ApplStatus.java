package com.app.pojos;

public enum ApplStatus {

	APPLIED,NOTAPPLIED
}
