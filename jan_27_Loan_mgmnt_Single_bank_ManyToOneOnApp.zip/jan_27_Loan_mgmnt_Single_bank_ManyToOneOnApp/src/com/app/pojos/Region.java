package com.app.pojos;

public enum Region {
	INDIA,ABROAD,ALL

}
