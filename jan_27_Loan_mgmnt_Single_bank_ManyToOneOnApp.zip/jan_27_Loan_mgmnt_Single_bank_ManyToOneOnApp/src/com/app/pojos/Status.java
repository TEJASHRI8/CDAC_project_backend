package com.app.pojos;


public enum Status {	
	PENDING,APPROVED,REJECTED
}
