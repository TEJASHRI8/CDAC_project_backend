package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="qualification")
public class Qualification {
	private Integer qualId;
	private String degreeName;
	private int yearOfPassing;
	private int obtainedMarks;
	private int totalMarks;
	private Student studentQuali;
	
	public Qualification() {
		// TODO Auto-generated constructor stub
	}
	
	public Qualification(String degreeName, int yearOfPassing, int obtainedMarks, int totalMarks) {
		super();
		this.degreeName = degreeName;
		this.yearOfPassing = yearOfPassing;
		this.obtainedMarks = obtainedMarks;
		this.totalMarks = totalMarks;
		}



/////////////////////////////////// one to one mapping for Student and Qualification
	
	@OneToOne
	@JoinColumn(name="stud_id")
	@JsonIgnore
	public Student getStudentQuali() {
		return studentQuali;
	}

	public void setStudentQuali(Student studentQuali) {
		this.studentQuali = studentQuali;
	}

	
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getQualId() {
		return qualId;
	}

	public void setQualId(Integer qualId) {
		this.qualId = qualId;
	}

	

	@Column(length = 20)
	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	@Column(length = 5)
	public int getObtainedMarks() {
		return obtainedMarks;
	}

	public void setObtainedMarks(int obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}

	@Column(length =5)
	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

	@Column(length =5)
	public int getYearOfPassing() {
		return yearOfPassing;
	}

	public void setYearOfPassing(int yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}

	@Override
	public String toString() {
		return "Qualification [qualId=" + qualId + ", degreeName=" + degreeName + ", obtainedMarks=" + obtainedMarks
				+ ", totalMarks=" + totalMarks + "]";
	}
	

}
