package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="loanStatus")
public class LoanStatus {
	
private Integer statusId;
private Status status;
private Bank banks;
private String message;
private LoanApplicationForm loanForm;

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public Integer getStatusId() {
	return statusId;
}
public void setStatusId(Integer statusId) {
	this.statusId = statusId;
}

@Column(length=10)
@Enumerated(EnumType.STRING)
public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}

@Column(length=200)
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
/////////////////////////////////////////
///////One to one mapping for Bank and LoanStatus
@OneToOne
@JoinColumn(name="bank_id")
@JsonIgnore
public Bank getBanks() {
	return banks;
}
public void setBanks(Bank banks) {
	this.banks = banks;
}
////////////////////////////////////////////
//one to one mapping between LoanStatus and LoanApplicationForm
@OneToOne
@JoinColumn(name="app_id")
@JsonIgnore
public LoanApplicationForm getLoanForm() {
	return loanForm;
}

public void setLoanForm(LoanApplicationForm loanForm) {
	this.loanForm = loanForm;
}



}
