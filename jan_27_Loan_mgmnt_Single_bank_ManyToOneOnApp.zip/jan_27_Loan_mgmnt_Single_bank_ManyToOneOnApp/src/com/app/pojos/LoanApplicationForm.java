package com.app.pojos;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="loanApplication")
public class LoanApplicationForm {
	private Integer applId;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date birthdate;
	private String fatherName;
	private String occupation;
	private Long income;
	@JsonIgnore
	private Gender gender;
	private String maritalStatus;
	private String adharCard;
	private ApplStatus applStatus;
	@JsonIgnore
	private Student student;
	private LoanStatus loanStatus;
	private Bank bank;
	public LoanApplicationForm() {
		// TODO Auto-generated constructor stub
	}

	public LoanApplicationForm(Date birthdate, String fatherName, String occupation, Long income, Gender gender,
			String maritalStatus, String adharCard) {
		super();
		this.birthdate = birthdate;
		this.fatherName = fatherName;
		this.occupation = occupation;
		this.income = income;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.adharCard = adharCard;
	}
	
	//////////////////////////////////////////////////////////
	///one to one mapping for loanApplicationForm and LoanStatus
	@JsonIgnore
	@OneToOne(mappedBy = "loanForm",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
	public LoanStatus getLoanStatus() {
		return loanStatus;
	}

	public void setLoanStatus(LoanStatus loanStatus) {
		this.loanStatus = loanStatus;
	}
	


	///////////////////////////////////////////////////////////////////////
	//Many to One mapping for Bank and LoanAplicationForm
	//@JsonBackReference
	@ManyToOne
	@JoinColumn(name="bank_id")
	@JsonIgnore
	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////
	
	//One to one Mapping of Student table into ApplicationForm
	@OneToOne 
	@JoinColumn(name="stud_id")
	public Student getStudent() {
		return student;
	}
	

	public void setStudent(Student student) {
		this.student = student;
	}
	
	//Convenience methods for Student
	public void addStudent(Student s)
	{
		this.student=s;
		s.setForm(this);	
	}
	
	public void removeStudent(Student s)
	{
		this.student=null;
		s.setForm(null);
	}
	
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getApplId() {
		return applId;
	}

	public void setApplId(Integer applId) {
		this.applId = applId;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(length = 20)
	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	@Column(length = 20)
	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	@Column(length = 20)
	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
	@Column
	public Long getIncome() {
		return income;
	}

	public void setIncome(Long income) {
		this.income = income;
	}

	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	@Column(length = 20)
	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	@Column(length = 20)
	public String getAdharCard() {
		return adharCard;
	}
	
	public void setAdharCard(String adharCard) {
		this.adharCard = adharCard;
	}
	
	@Column(length=25)
	@Enumerated(EnumType.STRING)
	public ApplStatus getApplStatus() {
		return applStatus;
	}

	public void setApplStatus(ApplStatus applStatus) {
		this.applStatus = applStatus;
	}

	@Override
	public String toString() {
		return "LoanApplicationForm [applId=" + applId + ", birthdate=" + birthdate + ", fatherName=" + fatherName
				+ ", occupation=" + occupation + ", income=" + income + ", gender=" + gender + ", maritalStatus="
				+ maritalStatus + ", adharCard=" + adharCard + "]";
	}	
	
}
