package com.app.pojos;

public enum Role {
BANK,ADMIN
}
