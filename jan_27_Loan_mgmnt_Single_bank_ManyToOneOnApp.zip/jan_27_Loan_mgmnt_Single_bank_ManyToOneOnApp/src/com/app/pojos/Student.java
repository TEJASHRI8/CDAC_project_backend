package com.app.pojos;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="student")
public class Student 
{
	private Integer sid;
	//@NotEmpty(message="Name must be supplied")
	private String fname;
	private String mname;
	//@NotEmpty(message="Last name must be supplied")
	private String lname;
	
	//@NotEmpty(message="Email must be supplied")
	private String email;
	
	private String mobile;
	
	//@Pattern(regexp="((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{5,20})",message="Invalid Password format")
	private String password;
	
	private String confirmPassword;
	
	private LoanApplicationForm form;
	
	private Qualification qualification;
	
	private Address address;
	
	private AdmittedCourse admittedCourse;
	
public Student() {
	// TODO Auto-generated constructor stub
}


public Student(String fname, String mname, String lname, String email, String mobile, String password,
		String confirmPassword) {
	super();
	this.fname = fname;
	this.mname = mname;
	this.lname = lname;
	this.email = email;
	this.mobile = mobile;
	this.password = password;
	this.confirmPassword = confirmPassword;
}


//One to One mapping of student to loanApplicationForm
@OneToOne(mappedBy = "student",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
public LoanApplicationForm getForm() {
	return form;
}

public void setForm(LoanApplicationForm form) {
	this.form = form;
}

////////////////////////one to one mapping for Qualification and Student

@OneToOne(mappedBy = "studentQuali",cascade = CascadeType.ALL,orphanRemoval = true)
public Qualification getQualification() {
	return qualification;
}


public void setQualification(Qualification qualification) {
	this.qualification = qualification;
}
//////////////////////////////////one to one mapping between Student and Address

@OneToOne(mappedBy = "studentAddr",cascade = CascadeType.ALL,orphanRemoval = true)
public Address getAddress() {

	return address;
}

public void setAddress(Address address) {
	this.address = address;
}
////////////////////////////////////// one to one mapping between Student and AdmittedCourse

@OneToOne(mappedBy = "studentCourse",cascade = CascadeType.ALL,orphanRemoval = true)
public AdmittedCourse getAdmittedCourse() {
	return admittedCourse;
}


public void setAdmittedCourse(AdmittedCourse admittedCourse) {
	this.admittedCourse = admittedCourse;
}

///////////////////////////////////////////////////////
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public Integer getSid() {
	return sid;
}

public void setSid(Integer sid) {
	this.sid = sid;
}

@Column(length = 20)
public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}
@Column(length=12)
public String getMobile() {
	return mobile;
}


public void setMobile(String mobile) {
	this.mobile = mobile;
}


@Column(length = 20)
public String getMname() {
	return mname;
}

public void setMname(String mname) {
	this.mname = mname;
}

@Column(length = 20)
public String getLname() {
	return lname;
}

public void setLname(String lname) {
	this.lname = lname;
}

@Column(length = 20, unique = true)
public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Column(length = 20, nullable = false)
public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}
@Transient
public String getConfirmPassword() {
	return confirmPassword;
}

public void setConfirmPassword(String confirmPassword) {
	this.confirmPassword = confirmPassword;
}


@Override
public String toString() {
	return "Student [sid=" + sid + ", fname=" + fname + ", mname=" + mname + ", lname=" + lname + ", email=" + email
			+ ", password=" + password + ", confirmPassword=" + confirmPassword + "]";
}
	

}
