package com.app.pojos;

public enum CourseType {
	UG,PG,VOCATIONAL_COURSE,PROFESSIONAL_COURSE

}
