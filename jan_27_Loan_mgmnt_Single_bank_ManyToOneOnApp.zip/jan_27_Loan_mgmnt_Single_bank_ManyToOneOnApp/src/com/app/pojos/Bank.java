package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="Bank")
public class Bank {
	private Integer bankId;
	private String bankName;
	private String branch;
	private String ifscCode;
	private String email;
	private String password;
	private Role role;
	private String contact;
	private LoanStatus status;
	private List<LoanApplicationForm> loanAppForms=new ArrayList<>();
	
		public Bank() {
		// TODO Auto-generated constructor stub
	}

	

	public Bank(String bankName, String branch, String ifscCode, String email, String password, Role role,String contact) {
		super();
		this.bankName = bankName;
		this.branch = branch;
		this.ifscCode = ifscCode;
		this.email = email;
		this.password = password;
		this.role = role;
		this.contact=contact;
	}
	//////////////////////////////ont to many mapping between loanapplicationform and Bank
	//@JsonManagedReference
	@JsonIgnore
	@OneToMany(mappedBy = "bank",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
	public List<LoanApplicationForm> getLoanAppForms() {
		return loanAppForms;
	}

	public void setLoanAppForms(List<LoanApplicationForm> loanAppForms) {
		this.loanAppForms = loanAppForms;
	}

///////////
	
	public void addLoanApplicationForm(LoanApplicationForm form)
	{
		loanAppForms.add(form);
		form.setBank(this);
	}

	public void removeLoanApplicationForm(LoanApplicationForm form)
	{
		loanAppForms.remove(form);
		form.setBank(null);
	}

  

///////////////////////////////One to one mapping for Bank and LoanStatus	
	
	@OneToOne(mappedBy = "banks",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.EAGER)
	@JsonIgnore
	public LoanStatus getStatus() {
		return status;
	}
	
	public void setStatus(LoanStatus status) {
		this.status = status;
	}
	////////////////////////convenience methods
	

	///////////////////////////////////////////////////////////////////
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}
	@Column(length=20)
	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Column(length=20)
	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Column(length=20)
	public String getIfscCode() {
		return ifscCode;
	}


	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	@Column(length=20)
	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}

	@Column(length=20)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Enumerated(EnumType.STRING)
	@Column(length=7)
	public Role getRole() {
		return role;
	}



	public void setRole(Role role) {
		this.role = role;
	}


	@Column(length=11)
	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "Bank [bankId=" + bankId + ", bankName=" + bankName + ", branch=" + branch + ", ifscCode=" + ifscCode
				+ ", email=" + email + ", password=" + password + ", role=" + role + "]";
	}

	
}
