package com.app.pojos;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EntireForm {
	private String degreeName;
	private int yearOfPassing;
	private int obtainedMarks;
	private int totalMarks;
	
	//student
	private Integer applId;
	private String fname;
	private String mname;
	
	private String lname;
	
	
	private String email;
	
	private String mobile;
	
	//loanApplication
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date birthdate;
	private String fatherName;
	private String occupation;
	private Long income;
	private String maritalStatus;
	private String adharCard;
	private String instituteName;
	private String courseName;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date startDate;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date endDate;
	private String ecity;
	private String country;
	private Long courseFees;
	private Long totalExpenses;
	private Long loanRequired;
	private int installments;
	//address
	private String addressLine;
	private String city;
	private String district;
	private String pinCode;
	public EntireForm() {
		
	}
	public EntireForm(String degreeName, int yearOfPassing, int obtainedMarks, int totalMarks,
			String fname, String mname, String lname, String email, String mobile, Date birthdate, String fatherName,
			String occupation, Long income, String maritalStatus, String adharCard, String instituteName,
			String courseName, Date startDate, Date endDate, String ecity, String country, Long courseFees,
			Long totalExpenses, Long loanRequired, int installments, String addressLine, String city, String district,
			String pinCode) {
		super();
		this.degreeName = degreeName;
		this.yearOfPassing = yearOfPassing;
		this.obtainedMarks = obtainedMarks;
		this.totalMarks = totalMarks;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.email = email;
		this.mobile = mobile;
		this.birthdate = birthdate;
		this.fatherName = fatherName;
		this.occupation = occupation;
		this.income = income;
		this.maritalStatus = maritalStatus;
		this.adharCard = adharCard;
		this.instituteName = instituteName;
		this.courseName = courseName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.ecity = ecity;
		this.country = country;
		this.courseFees = courseFees;
		this.totalExpenses = totalExpenses;
		this.loanRequired = loanRequired;
		this.installments = installments;
		this.addressLine = addressLine;
		this.city = city;
		this.district = district;
		this.pinCode = pinCode;
	}
	public String getDegreeName() {
		return degreeName;
	}
	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}
	public int getYearOfPassing() {
		return yearOfPassing;
	}
	public void setYearOfPassing(int yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}
	public int getObtainedMarks() {
		return obtainedMarks;
	}
	public void setObtainedMarks(int obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}
	public int getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public Long getIncome() {
		return income;
	}
	public void setIncome(Long income) {
		this.income = income;
	}
	
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getAdharCard() {
		return adharCard;
	}
	public void setAdharCard(String adharCard) {
		this.adharCard = adharCard;
	}
	public String getInstituteName() {
		return instituteName;
	}
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getEcity() {
		return ecity;
	}
	public void setEcity(String ecity) {
		this.ecity = ecity;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Long getCourseFees() {
		return courseFees;
	}
	public void setCourseFees(Long courseFees) {
		this.courseFees = courseFees;
	}
	public Long getTotalExpenses() {
		return totalExpenses;
	}
	public void setTotalExpenses(Long totalExpenses) {
		this.totalExpenses = totalExpenses;
	}
	public Long getLoanRequired() {
		return loanRequired;
	}
	public void setLoanRequired(Long loanRequired) {
		this.loanRequired = loanRequired;
	}
	public int getInstallments() {
		return installments;
	}
	public void setInstallments(int installments) {
		this.installments = installments;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	
	public Integer getApplId() {
		return applId;
	}
	public void setApplId(Integer applId) {
		this.applId = applId;
	}
	
	
		
}
