package com.app.pojos;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="admittedCourse")
public class AdmittedCourse {
	private Integer courseId;
	private String instituteName;
	private String courseName;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date startDate;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date endDate;
	private String ecity;
	private String country;
	private Long courseFees;
	private Long totalExpenses;
	private Long loanRequired;
	private int installments;
	private Student studentCourse;
	
	public AdmittedCourse() {
		// TODO Auto-generated constructor stub
	}

	public AdmittedCourse(String instituteName,String courseName, Date startDate, Date endDate, String ecity, String country,
			Long courseFees, Long totalExpenses, Long loanRequired) {
		super();
		this.instituteName = instituteName;
		this.courseName= courseName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.ecity = ecity;
		this.country = country;
		this.courseFees = courseFees;
		this.totalExpenses = totalExpenses;
		this.loanRequired = loanRequired;
	}
///////////////////////////////////////////////////////////////////////////
////////////one to one mapping for AdmittedCourse and Student
	
	@OneToOne
	@JoinColumn(name="stud_id")
	@JsonIgnore
	public Student getStudentCourse() {
		return studentCourse;
	}

	public void setStudentCourse(Student studentCourse) {
		this.studentCourse = studentCourse;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCourseId() {
		return courseId;
	}


	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
	
	@Column(length = 60)
	public String getInstituteName() {
		return instituteName;
	}
	

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}
	@Column(length=60)
	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	@Temporal(TemporalType.DATE)
	@Column
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	@Temporal(TemporalType.DATE)
	@Column
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	
	@Column
	public String getEcity() {
		return ecity;
	}

	public void setEcity(String ecity) {
		this.ecity = ecity;
	}

	@Column(length = 20)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	@Column(length = 12)
	public Long getCourseFees() {
		return courseFees;
	}

	public void setCourseFees(Long courseFees) {
		this.courseFees = courseFees;
	}
	@Column(length = 15)
	public Long getTotalExpenses() {
		return totalExpenses;
	}

	public void setTotalExpenses(Long totalExpenses) {
		this.totalExpenses = totalExpenses;
	}
	@Column(length = 15)
	public Long getLoanRequired() {
		return loanRequired;
	}

	public void setLoanRequired(Long loanRequired) {
		this.loanRequired = loanRequired;
	}

	@Column
	public int getInstallments() {
		return installments;
	}

	public void setInstallments(int installments) {
		this.installments = installments;
	}

	@Override
	public String toString() {
		return "AdmittedCourse [courseId=" + courseId + ", instituteName=" + instituteName + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", city=" + ecity + ", country=" + country + ", courseFees=" + courseFees
				+ ", totalExpenses=" + totalExpenses + ", loanRequired=" + loanRequired + "]";
	}
	
	
}
