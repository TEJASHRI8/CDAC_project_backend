package com.app.pojos;

public enum Amount {
	BELOW_4_LAKHS,BETWEEN_4_TO_7_LAKHS,ABOVE_7_LAKHS
}
